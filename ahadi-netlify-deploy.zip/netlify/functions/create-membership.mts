import type { Context, Config } from "@netlify/functions";
import Stripe from "stripe";
import { Resend } from "resend";

// Charges the first month's Direct Primary Care membership fee (plus the
// one time $125 registration fee) via Stripe, then emails a receipt to the
// member and a copy to info@ahadihealth.com.
//
// Requires these environment variables to be set in the Netlify site config
// (Site configuration > Environment variables) — never hard-code them here:
//   STRIPE_SECRET_KEY   (sk_test_... while testing, sk_live_... in production)
//   RESEND_API_KEY      (from resend.com)
//   BUSINESS_EMAIL      (defaults to info@ahadihealth.com if unset)
//   FROM_EMAIL          (e.g. "Ahadi Health <onboarding@resend.dev>" until a
//                        sending domain is verified in Resend)
//
// This charges a one-time first month + registration fee, not a recurring
// subscription. To bill monthly automatically after the first charge,
// replace the paymentIntents.create call below with a
// stripe.subscriptions.create against a Price object you set up once per
// plan in the Stripe Dashboard, and charge the registration fee separately.

const REGISTRATION_FEE_CENTS = 12500;

const PLAN_PRICES: Record<string, { label: string; amountCents: number }> = {
  Teen: { label: "Ages 13 to 17", amountCents: 3999 },
  Adult: { label: "Ages 18 to 64", amountCents: 7999 },
  Senior: { label: "Ages 65+", amountCents: 9900 },
  CoupleUnder65: { label: "Couple, both under 65", amountCents: 14999 },
  Couple65Plus: { label: "Couple, one or both 65+", amountCents: 18999 },
  Group: { label: "Group / Employer Rate", amountCents: 6999 },
};

export default async (req: Request, context: Context) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }

  const stripeSecretKey = process.env.STRIPE_SECRET_KEY;
  const resendApiKey = process.env.RESEND_API_KEY;
  const businessEmail = process.env.BUSINESS_EMAIL || "info@ahadihealth.com";
  const fromEmail = process.env.FROM_EMAIL || "Ahadi Health <onboarding@resend.dev>";

  if (!stripeSecretKey || !resendApiKey) {
    return new Response(
      JSON.stringify({ error: "Server not configured yet — STRIPE_SECRET_KEY and RESEND_API_KEY must be set as environment variables in the Netlify site." }),
      { status: 500 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body." }), { status: 400 });
  }

  const { paymentMethodId, plan, fullName, email, phone, dob, state } = body || {};

  if (!paymentMethodId || !plan || !PLAN_PRICES[plan] || !fullName || !email) {
    return new Response(JSON.stringify({ error: "Missing or invalid required fields." }), { status: 400 });
  }

  const stripe = new Stripe(stripeSecretKey);
  const resend = new Resend(resendApiKey);
  const { label, amountCents } = PLAN_PRICES[plan];
  const totalCents = amountCents + REGISTRATION_FEE_CENTS;

  try {
    const customer = await stripe.customers.create({
      name: fullName,
      email,
      phone,
      payment_method: paymentMethodId,
      invoice_settings: { default_payment_method: paymentMethodId },
      metadata: { dob: dob || "", state: state || "", plan },
    });

    const paymentIntent = await stripe.paymentIntents.create({
      amount: totalCents,
      currency: "usd",
      customer: customer.id,
      payment_method: paymentMethodId,
      confirm: true,
      receipt_email: email,
      description: `Ahadi Health Direct Primary Care membership (${label}) plus one time $125 registration fee`,
    });

    if (paymentIntent.status !== "succeeded") {
      return new Response(
        JSON.stringify({ error: "Payment was not completed.", status: paymentIntent.status }),
        { status: 402 }
      );
    }

    const monthlyFormatted = (amountCents / 100).toFixed(2);
    const registrationFormatted = (REGISTRATION_FEE_CENTS / 100).toFixed(2);
    const totalFormatted = (totalCents / 100).toFixed(2);
    const emailHtml = `
      <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
        <h2>Welcome to Ahadi Health</h2>
        <p>Hi ${fullName},</p>
        <p>Thanks for joining Ahadi Health Direct Primary Care. Here's your confirmation:</p>
        <table style="width:100%; border-collapse: collapse; margin: 16px 0;">
          <tr><td style="padding:6px 0; color:#666;">Membership</td><td style="padding:6px 0; text-align:right;">${label}</td></tr>
          <tr><td style="padding:6px 0; color:#666;">Monthly membership fee</td><td style="padding:6px 0; text-align:right;">$${monthlyFormatted}</td></tr>
          <tr><td style="padding:6px 0; color:#666;">One time registration fee</td><td style="padding:6px 0; text-align:right;">$${registrationFormatted}</td></tr>
          <tr><td style="padding:6px 0; color:#666; font-weight:bold;">Total charged today</td><td style="padding:6px 0; text-align:right; font-weight:bold;">$${totalFormatted}</td></tr>
          <tr><td style="padding:6px 0; color:#666;">State</td><td style="padding:6px 0; text-align:right;">${state || "N/A"}</td></tr>
          <tr><td style="padding:6px 0; color:#666;">Confirmation #</td><td style="padding:6px 0; text-align:right;">${paymentIntent.id}</td></tr>
        </table>
        <p>We'll be in touch soon to schedule your first visit.</p>
        <p>Ahadi Health</p>
      </div>`;

    try {
      await resend.emails.send({
        from: fromEmail,
        to: email,
        subject: "Your Ahadi Health Direct Primary Care membership confirmation",
        html: emailHtml,
      });
      await resend.emails.send({
        from: fromEmail,
        to: businessEmail,
        subject: `New DPC signup: ${fullName} (${label})`,
        html: emailHtml,
      });
    } catch (emailErr) {
      console.error("Email send failed (charge still succeeded):", emailErr);
    }

    return new Response(JSON.stringify({ success: true, paymentIntentId: paymentIntent.id }), { status: 200 });

  } catch (err: any) {
    console.error("Membership signup failed:", err);
    return new Response(JSON.stringify({ error: err.message || "Something went wrong processing payment." }), { status: 500 });
  }
};

export const config: Config = {
  path: "/api/create-membership",
};
