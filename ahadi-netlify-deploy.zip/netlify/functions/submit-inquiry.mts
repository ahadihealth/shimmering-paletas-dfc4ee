import type { Context, Config } from "@netlify/functions";
import { Resend } from "resend";

// Handles the two forms that don't involve payment: the Wound Care
// consult request (facility or individual/self) and the Employer group
// sign up inquiry. Emails the details to info@ahadihealth.com, and sends
// a short confirmation to the submitter if an email address was provided.
//
// Requires these environment variables (already set for the membership
// function, reused here):
//   RESEND_API_KEY
//   BUSINESS_EMAIL   (defaults to info@ahadihealth.com if unset)
//   FROM_EMAIL       (e.g. "Ahadi Health <onboarding@resend.dev>")

export default async (req: Request, context: Context) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405 });
  }

  const resendApiKey = process.env.RESEND_API_KEY;
  const businessEmail = process.env.BUSINESS_EMAIL || "info@ahadihealth.com";
  const fromEmail = process.env.FROM_EMAIL || "Ahadi Health <onboarding@resend.dev>";

  if (!resendApiKey) {
    return new Response(
      JSON.stringify({ error: "Server not configured yet: RESEND_API_KEY must be set as an environment variable in the Netlify site." }),
      { status: 500 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid request body." }), { status: 400 });
  }

  const { formType, fields, submitterEmail, submitterName } = body || {};

  const validTypes = ["wound_facility", "wound_individual", "employer"];
  if (!formType || !validTypes.includes(formType) || !fields || typeof fields !== "object") {
    return new Response(JSON.stringify({ error: "Missing or invalid request data." }), { status: 400 });
  }

  const formLabels: Record<string, string> = {
    wound_facility: "Mobile Wound Care: Facility Referral",
    wound_individual: "Mobile Wound Care: Individual Request",
    employer: "Direct Primary Care: Employer Group Sign Up",
  };

  const resend = new Resend(resendApiKey);

  const rowsHtml = Object.entries(fields)
    .filter(([, v]) => v !== undefined && v !== null && String(v).trim() !== "")
    .map(
      ([key, value]) =>
        `<tr><td style="padding:6px 10px 6px 0; color:#666; vertical-align:top; white-space:nowrap;">${escapeHtml(
          key
        )}</td><td style="padding:6px 0;">${escapeHtml(String(value))}</td></tr>`
    )
    .join("");

  const internalHtml = `
    <div style="font-family: sans-serif; max-width: 560px; margin: auto;">
      <h2>${escapeHtml(formLabels[formType])}</h2>
      <table style="width:100%; border-collapse: collapse; margin: 16px 0;">${rowsHtml}</table>
    </div>`;

  try {
    await resend.emails.send({
      from: fromEmail,
      to: businessEmail,
      subject: `New submission: ${formLabels[formType]}`,
      html: internalHtml,
    });

    if (submitterEmail) {
      const confirmationHtml = `
        <div style="font-family: sans-serif; max-width: 480px; margin: auto;">
          <h2>We received your request</h2>
          <p>Hi ${escapeHtml(submitterName || "there")},</p>
          <p>Thanks for reaching out to Ahadi Health. Here's a copy of what you submitted:</p>
          <table style="width:100%; border-collapse: collapse; margin: 16px 0;">${rowsHtml}</table>
          <p>We'll follow up with you soon.</p>
          <p>Ahadi Health</p>
        </div>`;

      try {
        await resend.emails.send({
          from: fromEmail,
          to: submitterEmail,
          subject: "Ahadi Health: we received your request",
          html: confirmationHtml,
        });
      } catch (confirmErr) {
        console.error("Submitter confirmation email failed (internal email still sent):", confirmErr);
      }
    }

    return new Response(JSON.stringify({ success: true }), { status: 200 });
  } catch (err: any) {
    console.error("Inquiry submission failed:", err);
    return new Response(JSON.stringify({ error: err.message || "Something went wrong sending this request." }), { status: 500 });
  }
};

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export const config: Config = {
  path: "/api/submit-inquiry",
};
